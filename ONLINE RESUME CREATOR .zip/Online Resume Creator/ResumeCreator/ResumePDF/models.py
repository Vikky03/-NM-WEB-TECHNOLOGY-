from django.db import models

# Create your models here.
class Profile(models.Model):
    Name=models.CharField(max_length=100)
    Phone_Number=models.CharField(max_length=100)
    Address=models.CharField(max_length=100)
    Email_ID=models.CharField(max_length=100)
    City=models.CharField(max_length=100)
    State=models.CharField(max_length=100)
    Degrees_Obtained=models.CharField(max_length=1000)
    Projects=models.CharField(max_length=1000)
    Skills=models.CharField(max_length=1000)
    WorkExperience=models.CharField(max_length=1000)
    VolunteerExperience=models.CharField(max_length=1000)

   
    